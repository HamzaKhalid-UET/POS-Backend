// ** entry point for all validators of the backend
export { default as authValidators } from './auth.validators';
