export { default as AuthController } from './auth-controller';
