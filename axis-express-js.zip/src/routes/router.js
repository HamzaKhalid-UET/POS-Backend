import AuthRouter from './auth.routes';

const BaseRouter = [];

export { AuthRouter, BaseRouter };
